echo "./convert 0";
./convert 0;

echo "./convert nan";
./convert nan;

echo "./convert 42.0f"
./convert 42.0f;

