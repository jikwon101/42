#include "B.hpp"

B::~B(){}
