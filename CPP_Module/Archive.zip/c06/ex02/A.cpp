#include "A.hpp"

A::~A(){}
