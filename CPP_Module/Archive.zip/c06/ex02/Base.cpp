#include "Base.hpp"

Base::~Base(){}
